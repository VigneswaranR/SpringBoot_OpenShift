package com.TCSNGA.MS1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TcsNgaMS1Controller {
	private static final Logger log = LoggerFactory.getLogger(TcsNgaMS1Controller.class);
//	@Autowired
//	public StudentDataConfiguration data;
	
	@RequestMapping(value="/data")
	public String getName() {
		log.info("inside /data controller");
		return "My first sample open shift application";
	}
	
}
