package com.TCSNGA.MS1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.sleuth.sampler.AlwaysSampler;
import org.springframework.cloud.sleuth.zipkin2.ZipkinSpanReporter;
import org.springframework.context.annotation.Bean;
//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
//@EnableEurekaClient
public class TcsNgaMS1Application {

	public static void main(String[] args) {
		SpringApplication.run(TcsNgaMS1Application.class, args);
	}
	@Bean
	public AlwaysSampler defaultSampler() {
	  return new AlwaysSampler();
	}
	
//	@Bean
//	public ZipkinSpanReporter makeZipkinSpanReporter() {
//	    return new ZipkinSpanReporter() {
//	        private HttpZipkinSpanReporter delegate;
//	        private String baseUrl;
//	 
//	        @Override
//	        public void report(Span span) {
//	  
////	            InstanceInfo instance = eurekaClient
////	              .getNextServerFromEureka("zipkin", false);
//	            if (!(baseUrl != null && 
//	              instance.getHomePageUrl().equals(baseUrl))) {
//	                baseUrl = instance.getHomePageUrl();
//	                delegate = new HttpZipkinSpanReporter(baseUrl,
//	                  zipkinProperties.getFlushInterval(), 
//	                  zipkinProperties.getCompression().isEnabled(), 
//	                  spanMetricReporter);
//	  
//	                if (!span.name.matches(skipPattern)) delegate.report(span);
//	            }
//	        }
//	    };
//	}
}
