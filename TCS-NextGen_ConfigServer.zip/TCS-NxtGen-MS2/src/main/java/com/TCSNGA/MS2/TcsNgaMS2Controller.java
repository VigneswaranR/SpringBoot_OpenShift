package com.TCSNGA.MS2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class TcsNgaMS2Controller {
	private static final Logger log = LoggerFactory.getLogger(TcsNgaMS2Controller.class);  

	@RequestMapping(value="/data2")
	public String getName() {
		log.info("inside /data2 controller");
		return "2nd hello world";
	}
	
	@RequestMapping(value="/restcall2")
	public String getRestCall() {
		log.info("inside /restcall2 controller");
		RestTemplate rt = new RestTemplate();
		String fooResourceUrl
		  = "http://openjdk-app-pocbyvigneswaran.1d35.starter-us-east-1.openshiftapps.com/";
		log.info("http://openjdk-app-pocbyvigneswaran.1d35.starter-us-east-1.openshiftapps.com/");
		ResponseEntity<String> response
		  = rt.getForEntity(fooResourceUrl + "/data", String.class);
		log.info(response.getBody());
		return response.getBody();
	}
}
